export { default as Partners } from "./Partners";
export { default as Partners2 } from "./Partners2";