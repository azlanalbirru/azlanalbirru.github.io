export { default as Testimonials } from "./Testimonials";
export { default as Testimonials2 } from "./Testimonials2";