export { default as Skills } from "./Skills";
export { default as Skills2 } from "./Skills2";