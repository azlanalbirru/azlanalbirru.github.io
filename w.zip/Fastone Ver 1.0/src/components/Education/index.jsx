export { default as Education } from "./Education";
export { default as Education2 } from "./Education2";