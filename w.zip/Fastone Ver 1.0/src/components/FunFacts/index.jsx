export { default as FunFacts } from "./FunFacts";
export { default as FunFacts2 } from "./FunFacts2";
export { default as FunFacts3 } from "./FunFacts3";