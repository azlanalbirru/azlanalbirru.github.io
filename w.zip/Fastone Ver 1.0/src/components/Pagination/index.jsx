export { default as Pagination } from "./Pagination";
export { default as Pagination2 } from "./Pagination2";