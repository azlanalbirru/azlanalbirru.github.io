export { default as AboutUs } from "./AboutUs";
export { default as AboutUs2 } from "./AboutUs2";