export { default as FreelanceWork } from "./FreelanceWork";
export { default as FreelanceWork2 } from "./FreelanceWork2";
export { default as FreelanceWork3 } from "./FreelanceWork3";