export { default as FeaturedArea } from "./FeaturedArea";
