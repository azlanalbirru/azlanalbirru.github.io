import React from "react";
import ReactDOM from "react-dom/client";
import "./styles/global.css";
import App from "./App";

const fastone = ReactDOM.createRoot(document.getElementById("fastone"));

fastone.render(<App />);
