import ExpImg1 from "../assets/images/resources/expImg1.jpg";
import ExpImg2 from "../assets/images/resources/expImg2.jpg";
import ExpImg3 from "../assets/images/resources/expImg3.jpg";
import ExpImg4 from "../assets/images/resources/expImg4.jpg";

export const workExp = [
  {
    expCount: "1",
    expDate: "2011 - 2014",
    expImg: ExpImg1,
    expTitle: "UI/UX Creative Design",
    expSubTitle: "Incident Software House",
    expDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  },
  {
    expCount: "2",
    expDate: "2015 - 2020",
    expImg: ExpImg2,
    expTitle: "Art & Multimedia",
    expSubTitle: "Oxford Company",
    expDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  },
  {
    expCount: "3",
    expDate: "2011 - 2014",
    expImg: ExpImg3,
    expTitle: "Digital Marketing",
    expSubTitle: "Your Software House",
    expDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  },
  {
    expCount: "4",
    expDate: "2015 - 2020",
    expImg: ExpImg4,
    expTitle: "UI/UX Creative Design",
    expSubTitle: "Incident Software House",
    expDesc:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  },
];
