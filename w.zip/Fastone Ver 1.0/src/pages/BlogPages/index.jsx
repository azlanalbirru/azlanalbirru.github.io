export { default as BlogPage } from "./BlogPage";
export { default as BlogPage2 } from "./BlogPage2";
export { default as BlogDetail } from "./BlogDetail";
