export { default as ServicePage } from "./ServicePage";
export { default as ServiceDetail } from "./ServiceDetail";